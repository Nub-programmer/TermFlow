from termflow.ui.app import TermFlowApp
import sys

def main():
    """Entry point for TermFlow."""
    app = TermFlowApp()
    app.run()

if __name__ == "__main__":
    main()
