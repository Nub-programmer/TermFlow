import random

def get_quote():
    reflections = [
        "Focus on being productive instead of busy. — Tim Ferriss",
        "Simplicity is the soul of efficiency. — Austin Freeman",
        "The secret of getting ahead is getting started. — Mark Twain",
        "Your mind is for having ideas, not holding them. — David Allen",
        "We are what we repeatedly do. Excellence is a habit. — Aristotle",
        "The best way to predict the future is to invent it. — Alan Kay",
        "Science is organized knowledge. Wisdom is organized life. — Immanuel Kant",
        "Deep work is the superpower of the 21st century. — Cal Newport",
        "The obstacle is the way. — Marcus Aurelius",
        "Code is poetry. — Anonymous"
    ]
    return random.choice(reflections)
