from termflow.termflow.ui.app import TermFlowApp

def main():
    TermFlowApp().run()

if __name__ == "__main__":
    main()
