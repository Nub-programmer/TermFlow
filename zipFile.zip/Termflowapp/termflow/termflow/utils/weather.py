import requests

def get_weather(city=None):
    return "N/A"
