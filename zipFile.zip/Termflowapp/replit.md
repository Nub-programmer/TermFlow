# TermFlow - Replit Agent Guide

## Overview

TermFlow is a minimalist terminal productivity dashboard built with Python and the Textual TUI framework. It provides a keyboard-driven interface combining productivity tools: a real-time clock, todo list with colored tags, Pomodoro timer with session tracking, live weather updates, and motivational quotes. The application runs entirely in the terminal, offering a distraction-free productivity environment.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Framework & UI Layer
- **Textual Framework**: The entire UI is built using Textual, a Python TUI framework built on Rich for terminal rendering
- **Panel-Based Layout**: The app uses a modular panel architecture where each feature (clock, todos, pomodoro, info) is an independent widget
- **Reactive State**: Uses Textual's `reactive` system for real-time UI updates (timer countdown, clock updates)

### Application Structure
```
termflow/
├── ui/app.py          # Main application class, keybindings, layout composition
├── panels/            # Independent UI components
│   ├── clock.py       # Real-time clock widget
│   ├── todo.py        # Todo list with tag support
│   ├── pomodoro.py    # Pomodoro timer with session tracking
│   └── info.py        # Weather and quotes display
└── utils/             # Data and service utilities
    ├── storage.py     # Centralized persistence (XDG-compliant paths)
    ├── todos.py       # Todo CRUD operations (legacy, being migrated)
    ├── weather.py     # Weather API integration
    └── quotes.py      # Quotes API integration
```

### Data Persistence
- **XDG Base Directory Compliance**: Uses `platformdirs` to store data in proper OS locations
  - Config: `~/.config/termflow/config.toml`
  - Data: `~/.local/share/termflow/todos.json`
- **File Formats**: JSON for todos, TOML for configuration
- **Graceful Degradation**: All file operations have fallback defaults if files are missing or corrupted

### Configuration System
- TOML-based configuration file
- Supports: city (weather), pomodoro_duration, theme
- Uses `tomli`/`tomllib` for reading, `tomli-w` for writing
- Provides sensible defaults when config is missing

### Keyboard-First Design
- All major actions mapped to single keys (a=add, d=delete, space=toggle, p=pomodoro, q=quit)
- Help overlay accessible via `?` or `h`
- Tab navigation between panels

## External Dependencies

### Python Packages
- **textual**: TUI framework (core dependency)
- **rich**: Terminal formatting (used by Textual)
- **requests**: HTTP client for API calls
- **platformdirs**: Cross-platform XDG directory handling
- **tomli/tomli-w**: TOML config parsing and writing

### External APIs
- **Open-Meteo API** (`api.open-meteo.com`): Free weather data, no API key required. Uses hardcoded city coordinates for common cities.
- **DummyJSON Quotes** (`dummyjson.com/quotes`): Random motivational quotes. Falls back to hardcoded quotes on failure.

### Error Handling for External Services
- All API calls wrapped in try/except with fallback values
- Weather displays "N/A (Offline)" on failure
- Quotes fall back to curated offline collection
- 5-second timeout on all HTTP requests